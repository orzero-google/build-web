<img src="./setup_images/setup_footer.jpg"/>
<a href="http://www.phpobjectgenerator.com" title="Php Object Generator Homepage">PHP Object Generator</a> |
<a href="http://www.phpobjectgenerator.com/plog" title="Php Weblog">POG Weblog</a> |
<a href="http://groups.google.com/group/Php-Object-Generator" title="POG Google Group">Google group</a> |
<a href="http://www.phpobjectgenerator.com/plog/tutorials" title="POG Tutorials">Tutorials</a> |
<a href="mailto:pogguys@phpobjectgenerator.com" title="Contact the POG authors">Contact us</a>